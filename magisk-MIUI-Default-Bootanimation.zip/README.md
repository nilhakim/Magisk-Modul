# Magisk MIUI Bootanimation

Default MIUI Bootanimation
timezone=Asia/Kuala_Lumpur
region=MY
region2=MY

For more information about modules and repos, please check the [official documentation](https://github.com/topjohnwu/Magisk/blob/master/docs/modules.md)
